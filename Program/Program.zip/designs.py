def print_bar(): 
    print("=" * 100)